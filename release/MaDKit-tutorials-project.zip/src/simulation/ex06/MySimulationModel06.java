package simulation.ex06;

/**
 * Stocking some global properties for this tutorial.
 */

 public class MySimulationModel06{

    public static final String MY_COMMUNITY = "simu";
    public static final String SIMU_GROUP = "simu";
    public static final String AGENT_ROLE = "agent";
    public static final String SPY_ROLE = "spy";
    public static final String SCH_ROLE = "scheduler";

}

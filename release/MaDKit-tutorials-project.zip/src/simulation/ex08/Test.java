package simulation.ex08;

import madkit.kernel.Agent;
import madkit.kernel.Madkit;

public class Test extends Agent {

    /**
     * @param args
     */
    public static void main(String[] args) {
	new Madkit();
    }

}

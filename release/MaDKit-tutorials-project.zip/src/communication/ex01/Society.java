package communication.ex01;

public class Society {

    public static final String COMMUNITY = "communication";
    public static final String GROUP = "ex01";
    public static final String ROLE = "ping agent";

}

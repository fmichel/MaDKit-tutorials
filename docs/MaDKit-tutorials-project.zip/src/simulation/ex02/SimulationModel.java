package simulation.ex02;

/**
 * Stocking some global properties for this tutorial.
 * 
 * @author Fabien Michel
 * @version 0.9
 */
public class SimulationModel {

    public static final String MY_COMMUNITY = "simu";
    public static final String SIMU_GROUP = "simu";
    public static final String ROLE = "bot";
    public static final String ANOTHER_ROLE = "anotherRole";

}
